/************************************
 * British Geological Survey, 2019  *
 * Xiaoyang Wu                      *
 * ANIMOD Version: 1.00             *
 * Date: 06/2019                    *
 ***********************************/


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "complexme.h"

void fdc(double lam, double mu, double rho, double fd, double af, double cd, double ppor, double kf, double tau, double w, \
         complex& c11, complex& c33, complex& c12, complex& c13, complex& c44);
void anis(double w, double vp0,double vs0, double r0, double f0,double por0, double cd0, double tau0,double fd,\
          complex& a1, complex& a2, complex& a3, complex& a4, complex& a5, complex& a6);



int main()
{
// This program calculates the frequency-dependent elastic moduli for fluid saturated media 
// using Chapman Squirt flow model(2003) with vertical fractures.
	complex a1,a2,a3,a4,a5,a6; 
	double freq, par[9];
	double vp0,vs0,r0,por0,f0,cd0,tau0,fd;
	
	
//read input parameters from .txt file
   FILE *fp1 = fopen("par_animod.txt","r");
   int ij=0;
   if(fp1 == NULL)
   {
        printf("Open file failure!");
        exit(1);
   }
   else
   {
	    while( fscanf(fp1, "%lf", &par[ij]) == 1 ) 
        { 
            //printf("%lf\n", par[ij]); 
			ij++;
        } 
        fclose(fp1);
   }
   
// lower medium properties
   vp0 = par[0];
   vs0 = par[1];
   r0 = par[2];
   f0  = par[3];
   por0 = par[4];
   cd0 = par[5];
   tau0 = par[6];
   fd = par[7];
   freq = par[8];
	
	anis(freq, vp0,vs0,r0,f0,por0,cd0,tau0,fd,a1, a2, a3, a4, a5, a6);


    printf("c11 = %f + %f *i\n", a1.r, a1.i);
	printf("c33 = %f + %f *i\n", a2.r, a2.i);
	printf("c12 = %f + %f *i\n", a3.r, a3.i);
	printf("c13 = %f + %f *i\n", a4.r, a4.i);
	printf("c44 = %f + %f *i\n", a5.r, a5.i);
    printf("c66 = %f + %f *i\n", a6.r, a6.i);
	
	return 0;
}


void anis(double w, double vp0,double vs0, double r0, double f0,double por0, double cd0, double tau0,double fd,\
          complex& a1, complex& a2, complex& a3, complex& a4, complex& a5, complex& a6)
{
//  This subroutine calculates the six elastic stiffness values at a designated frequency w for HTI media.
//  a1 = c11;  a2 = c33;   a3 = c12;   a4 = c13;   a5 = c44;   a6 = c66;
   double  rho, kf0;

   double  tau, ar0, af0;

   double  mu, lam, lc, mc, freq, por;

   double  kf, cd, ar, af, zero;

   complex lfw, mfw, c11, c12, c13, c33, c44, cmu, cla;

   complex c66;

   zero=0;

// define the reference parameters

/*   vp0 = 2.61;
   vs0 = 1.3;
   r0   = 1.75;
   f0  = 10;
   por0= .08;
   cd0 = 0;
   tau0 = 2e-5;  
   fd = .1;*/
   
   kf0 = 2;
   af0 = 0.1;

// calculate the common elastic moduli

   mu  = vs0*vs0*r0;
   lam = vp0*vp0*r0 - 2*mu;

   fdc(lam, mu, r0, zero, af0, cd0, por0, kf0, tau0, f0, c11, c33, c12, c13, c44);

   lc = 2*lam - c12.r;
   mc = 2*mu - c44.r;



// define the varying parameters

   freq = w;
   por = por0;
   rho = r0;
   kf  = 2;
   cd  = cd0;
   af  = af0;
   tau = tau0;


// calculate the final elastic modulus

   fdc(lam, mu, rho, fd, af, cd, por, kf, tau, w, c11, c33, c12, c13, c44);

   cla.r = (lc - lam); cla.i=0.0;

   cmu.r = ( mc - mu); cmu.i=0.0;

   c11 = c11 + (cla + 2*cmu);

   c33 = c33 + (cla + 2*cmu);

   c12 = c12 + cla;

   c13 = c13 + cla;

   c44 = c44 + cmu;

   c66 = 0.5*(c11 - c12);

   a1.r = c11.r; a1.i=c11.i;

   a2.r = c33.r; a2.i = c33.i;

   a3.r = c12.r; a3.i = c12.i;

   a4.r = c13.r; a4.i = c13.i;

   a5.r = c44.r; a5.i = c44.i;

   a6.r = c66.r; a6.i = c66.i;

   return;

}


void fdc(double lam, double mu, double rho, double fd, double af, double cd, double ppor, double kf, double tau, double w, \
         complex& c11, complex& c33, complex& c12, complex& c13, complex& c44) 
{
//  This subroutine takes real values for the lamee constants (lam & mu), the density (rho) fracture 
//  density (fd), fracture length in meters (af), the microcrack density (cd), the porosity (ppor)
//  the parameter gamma (gam) related to fluid compressibility, the time constant (tau) related to the
//  inverse of the squirt flow frequency and the wave frequency (w). 

//  The output is a complex elastic tensor, with the x_3 axis assumed to be the axis of symmetry. This 
//  elastic tensor is characterised by the constants c11, c33, c12, c13 and c44.


    double  cpor, fpor, beta, io;
    double  tauf, gam, gamp, kc, ar, v, pi, crit, l2, l3;
    double  po;
    double  pr;
    
    complex i1, c66, kap,i;
    
    complex a, b, c, z1, z2, z3, z4, z5, z6, z7, z8, z9;
    
    complex d1, d2, f1, f2, g1, g2, g3, vel, f;
    
    complex aa1, aa2, aa3, aa4, aa5, aa6, bb1, bb2, bb3, bb4, bb5;
    
    complex jj1, jj2, jj3, jj4, kk1, kk2, kk3, kk4, kk5, kk6;
    
    complex mm1, mm2, mm3, mm4, mm5, mm6;
    
    complex x1, x2, x3, v1, v2, v3;
    
    int j, k, l;
    
    //i=(0,1)
    i1.r=0.0; i1.i=1.0;
     
//      parameter values


    ar=1E-3;
    gamp=1;
    tauf=5000*af*tau;

    cpor=4.187*cd*ar;
    fpor=4.187*fd*ar;
 
 
    
 
//       some definitions                                              
 
 
    po=(((lam+2*mu)/rho) - 2*(mu/rho))/(2*((lam+2*mu)/rho) - (mu/rho));
 
 
    gam=(1.18*( 1 + (1.3333333)*((mu)/(kf))))/(1-po);
                                          
    pi=3.1415926535;
 
    l2=(lam*lam) + (1.33333333*lam*mu) +(0.8*mu*mu);
 
    l3=4*(lam*lam + (1.33333*lam*mu) + (0.5333333*mu*mu) );
 
    v=lam/(2*(lam+mu));
 
    kap=lam+ (0.66666666*mu);
 
 
    crit=(pi*mu*ar)/(2-2*v);
 
    io=(cpor/ar)/( (cpor/ar) + ppor);
 
 
    kc=(pi*mu*ar)/(2*(1-v)*kf);
 
    beta=(fpor/ar)/((cpor/ar) + ppor);
 
 
// calculate d1 and d2, f1 and f2

   

   z1=(io/(3 + 3*kc)) + (gamp - gamp*io);
   z2=((i1*w*tau)*( 1/(3 + 3*kc) -gamp))/(1+i1*w*tau);


   z3=io +( (io*beta)/(1+i1*w*tauf));

   a=z1 - (z2*z3);

   b=beta/( (1+kc)*(1+i1*w*tauf) );


   z4=((1-io)*gam) + (( (1-io)*beta)/(1+i1*w*tauf));
   z5=(io + ((io*beta)/(1 + i1*w*tauf)))*((1+i1*w*gam*tau)/(1+i1*w*tau));
   
   c= z4 + z5;



   d1=a/c;



   d2=b/c;




   x1=io*d1*(1+i1*w*gam*tau)/(1+i1*w*tau);
   x2= d1*(1-io);
   x3=(((1/(3 + 3*kc)) -gamp)*io*i1*w*tau)/(1+i1*w*tau);

   f1=(x1 + x2 + x3)/(1 + i1*w*tauf);



   v1=(i1*w*tauf)/(1 + kc);
   v2=(io*d2*(1+i1*w*gam*tau))/(1+i1*w*tau);
   v3=d2*(1-io);


   f2=(v1+v2+v3)/(1+i1*w*tauf);


// end definiton of d1, d2, f1, f2

// define g1, g2, g3


  
   g1=(i1*w*tau)/( (1+i1*w*tau)*(1+kc));


   g2=(d1 +(d1*i1*w*tau*gam) - (gamp*i1*w*tau))/(1+i1*w*tau);


   g3=(d2*(1+i1*w*gam*tau))/(1+i1*w*tau);



// end of definition of g1, g2, g3

// calculation of c_11


   aa1=(l2/crit) + ((32*(1-v)*mu)/(15*(2-v)*pi*ar));

   aa2=(((l2/crit)+kap)*g1)+((((3*kap*kap)/crit) +3*kap)*g2)+ ( (((lam*kap)/crit)+lam)*g3);


// crack correction cpor*(aa1-aa2)



   aa3=( (3*lam*lam + 4*lam*mu+ (mu*mu*(36+20*v)/(7-5*v)) )*3*(1-v))/(4*(1+v)*mu);

   aa4=(1+(3*kap)/(4*mu))*(3*kap*d1 + lam*d2);



// porosity correction ppor*(aa3-aa4)

   aa5=lam*lam/crit;

   aa6=((3*lam*kap/crit)+(3*kap))*f1 + ( ( (lam*lam/crit) + lam)*f2);


// fracture correction fpor*(aa5-aa6)

   c11= (lam+2*mu) + ((-1)*cpor*(aa1-aa2)) +  ((-1)*ppor*(aa3-aa4)) + ((-1)*fpor*(aa5-aa6));



// calculation of c33


   bb2=(((l2/crit)+kap)*g1)+(( ((3*kap*kap)/crit) +3*kap)*g2)+(((((lam+2*mu)*kap)/crit)+(lam+2*mu))*g3);


// crack correction cpor*(aa1-bb2)



   bb3=(1+((3*kap)/(4*mu)))*( (3*kap*d1) + ((lam+2*mu)*d2) );

   

// porosity correction ppor*(aa3-bb3)

   bb4=(lam +2*mu)*(lam+2*mu)/crit;

   bb5=(( (3*kap*(lam+2*mu)/crit) +3*kap)*f1) + f2*(((lam+2*mu)*(lam+2*mu)/crit) + lam + 2*mu);

   

// fracture correction fpor*(bb4-bb5)


   c33=(lam+2*mu) + ((-1)*cpor*(aa1-bb2)) + ((-1)*ppor*(aa3-bb3)) +((-1)*fpor*(bb4-bb5));


// calculation of c44


   jj1=(0.2666666666667)*mu*mu*(1-g1)/crit;

   jj2=((1.6)*(1-v)*mu)/(pi*ar*(2-v));

// crack correction cpor*(jj1 + jj2)



   jj3=(15*(1-v)*mu)/(7-5*v);

// porosity correction ppor*jj3



   vel=ppor*jj3;

   jj4=(4*(1-v)*mu)/(pi*(2-v)*ar);

// fracture correction fpor*jj4


   vel=fpor*jj4;

   c44= mu + ((-1)*cpor*(jj1+jj2)) + ((-1)*ppor*jj3) + ((-1)*fpor*jj4);


// calculation of c12

   kk1=(l3/crit) + ((32*(1-v)*mu)/(15*(2-v)*pi*ar));

   kk2=(((l3/crit) + 4*kap)*g1) + (((12*kap*kap/crit) + 12*kap)*g2) + (((4*lam*kap/crit) + 4*lam)*g3);

// crack correction cpor*(kk1-kk2)

   kk3= ((12*lam*lam + 16*lam*mu +(mu*mu*64/(7-5*v)))*3*(1-v))/(4*(1+v)*mu);


   kk4=( (1.5*kap/mu) + 2)*(6*kap*d1 + 2*lam*d2);


// porosity correction ppor*(kk3-kk4)


   kk5=4*lam*lam/crit;

   kk6=(f1*( (12*kap*lam/crit) + 12*kap)) + (f2*( (4*lam*lam/crit) + 4*lam));

// fracture correction fpor*(kk5-kk6)


   c12=0.5*( (4*lam+4*mu) + ((-2)*c11) + ((-1)*cpor*(kk1-kk2)) + ((-1)*ppor*(kk3-kk4)) + ((-1)*fpor*(kk5-kk6)) );



// calculation of c13

   mm2=(((l3/crit) + 4*kap)*g1) + (((12*kap*kap/crit) + 12*kap)*g2)+(((4*(lam+mu)*kap/crit) + 4*(lam+mu))*g3);

// crack correction cpor*(kk1-mm2)

   mm4=( (1.5*kap/mu) + 2)*(6*kap*d1 + (2*lam+2*mu)*d2);

// porosity correction ppor*(kk3-mm4)

   mm5=(4*(lam+mu)*(lam+mu))/crit;

   mm6=(f1*( (12*kap*(lam+mu)/crit) + 12*kap)) + (f2*( (4*(lam+mu)*(lam+mu)/crit) + 4*(lam+mu)));

// fracture correction fpor*(mm5-mm6)


   c13=0.5*( (4*lam+4*mu) + ((-1)*(c11 + c33)) + ((-1)*cpor*(kk1-mm2)) + ((-1)*ppor*(kk3-mm4))+((-1)*fpor*(mm5-mm6)) );

   return;

}


