/************************************
 * British Geological Survey, 2019  *
 * Xiaoyang Wu                      *
 * PPCOEF Version: 1.00             *
 * Date: 06/2019                    *
 ***********************************/
 
#include <stdio.h>
#include <math.h>
#include "complexme.h"
#include <stdlib.h>


/*************subroutine declaration***********/
void fdc(double lam, double mu, double rho, double fd, double af, double cd, double ppor, double kf, double tau, double w, complex& c11, complex& c33, complex& c12, complex& c13, complex& c44);
void avo_rp(double w, double vp0, double vs0, double f0, double r, double por0, double cd0, double tau,complex& lfw, complex& mfw);
void pol(double lamr, double lami, double mur, double mui, double r, double s1, double s3r, double s3i, double er[2], double ei[2]);
void radd(double a[2][2], double b[2][2], double c[2][2]);
void rsubt(double a[2][2], double b[2][2], double c[2][2]);
void rmult(double a[2][2], double b[2][2], double c[2][2]);
void rinv(double a[2][2], double b[2][2]);
void square(double ar, double ai, double *br, double *bi);
void quad(double ar, double ai, double br, double bi, double cr, double ci, double *xr, double *xi, double *yr, double *yi);
void dcinv(double x[2][2], double y[2][2], double a[2][2], double b[2][2]);
void dcmult(double a[2][2], double b[2][2], double u[2][2], double v[2][2], double x[2][2], double y[2][2]);


int main()
{
//This program calculates the pp reflection coefficient from the interface 
//of a frequency-dependent fluid saturated material overlay by an isotropic media.	

   double ap, bp, rp, r, norm;

   double s1, s3pr, s3sr, s3pi, s3si;

   double s3pp, s3sp;

   double theta, gamp, deg[90];

   double xp[2][2], yp[2][2], amp[90], phase[90];

   double lamr, lami, mur, mui;

   double epr[2], epi[2], esr[2], esi[2];

   double *t1r, *t1i, *t2r, *t2i, *u1r, *u1i, *u2r, *u2i;

   double t1[2][2], t2[2][2], wr[2][2], wi[2][2];

   double m1r[2][2], m1i[2][2], m2r[2][2], m2i[2][2];

   double refr[2][2], refi[2][2];

   double a1r, a1i, a2r, a2i, a3r, a3i;

   double xr[2][2], yr[2][2], xi[2][2], yi[2][2];

   double xinvr[2][2], xinvi[2][2], yinvr[2][2];

   double yinvi[2][2], freq, xpin[2][2], ypin[2][2];
   
   double vp0,vs0,f0,por0,cd0,tau,par[11];
   int index, k, l;

   complex cl, cm;

// memory allocation to pointers
   t1r = (double *)malloc(1 * sizeof(double));
   t1i = (double *)malloc(1 * sizeof(double));
   t2r = (double *)malloc(1 * sizeof(double));
   t2i = (double *)malloc(1 * sizeof(double));
   u1r = (double *)malloc(1 * sizeof(double));
   u1i = (double *)malloc(1 * sizeof(double));
   u2r = (double *)malloc(1 * sizeof(double));
   u2i = (double *)malloc(1 * sizeof(double));
	if (t1r == NULL || t1i == NULL || t2r == NULL||t2i == NULL \
	||u1r == NULL || u1i == NULL || u2r == NULL || u2i == NULL )
	{    
        printf("Error in allocating memory.");
        exit(1);
    }

//read input parameters from .txt file
   FILE *fp1 = fopen("par_ppcoef.txt","r");
   int ij=0;
   if(fp1 == NULL)
   {
        printf("Open file failure!");
        exit(1);
   }
   else
   {
	    while( fscanf(fp1, "%lf", &par[ij]) == 1 ) 
        { 
            //printf("%lf\n", par[ij]); 
			ij++;
        } 
        fclose(fp1);
   }

// upper medium properties

   ap = par[0];
   bp = par[1];
   rp = par[2];

// lower medium properties
   vp0 = par[3];
   vs0 = par[4];
   f0  = par[5];
   r   = par[6];
   por0 = par[7];
   cd0 = par[8];
   tau = par[9];
   
// input to be calculated frequency for lower medium 
   freq=par[10];
   
   
   avo_rp(freq, vp0, vs0, f0, r, por0, cd0, tau, cl, cm);
   lamr = cl.r;
   lami = cl.i;
   mur =  cm.r;
   mui = cm.i;
// THE saturated fluid density
//   r =  2.45;


//  input theta

   for (index=0; index<90;index++)
	{
       theta=(0.01745)*(index+1);
       deg[index]=index+1;

//  calculate s1, common horizontal slowness
       s1=sin(theta)/ap;

//  calculate s3 for the four possibilities

       s3pp= sqrt( (1/(ap*ap)) - (s1*s1));
       s3sp= sqrt( (1/(bp*bp)) - (s1*s1));

//  calculate gamma

       gamp = 1-(2*bp*bp*s1*s1);


//  calculate impedance matrices for the upper medium


       xp[0][0] = ap*s1;
       xp[0][1] = bp*s3sp;
       xp[1][0] = -1*rp*ap*gamp;
       xp[1][1] = 2*rp*bp*bp*bp*s1*s3sp;

       yp[0][0] = -2*rp*ap*bp*bp*s1*s3pp;
       yp[0][1] = -1*rp*bp*gamp;
       yp[1][0] = ap*s3pp;
       yp[1][1] = -1*bp*s1;


// define coefficients of quadratic equation on slowness
// 
// arising from 5/11/04

       a1r = lamr*mur + 2*mur*mur + (-1)*lami*mui + (-2)*mui*mui;
       a1i = lami*mur + 2*mui*mur + lamr*mui + 2*mur*mui;


       a2r = s1*s1*(lamr +2*mur)*(lamr + 2*mur) + s1*s1*(-1)* \
      (lami + 2*mui)*(lami + 2*mui) \
      + s1*s1*mur*mur + (-1)*s1*s1*mui*mui + (-1)*r*mur + (-1)*r*lamr + \
      (-1)*2*r*mur + (-1)*s1*s1*(lamr + mur)*(lamr + mur) \
      + s1*s1*(lami + mui)*(lami + mui);

       a2i = 2*s1*s1*(lamr + 2*mur)*(lami + 2*mui) + 2*s1*s1*mur*mui \
      + (-1)*r*mui + (-1)*r*lami + (-2)*r*mui \
      + (-2)*s1*s1*(lamr + mur)*(lami + mui);

       a3r = s1*s1*s1*s1*( lamr*mur + 2*mur*mur + (-1)*lami*mui \
      + (-2)*mui*mui) + (-1)*r*s1*s1*(lamr + 2*mur) + \
      (-1)*r*s1*s1*mur + r*r;

       a3i = s1*s1*s1*s1*(lami*mur + 2*mui*mur + lamr*mui + 2*mur*mui) \
      + (-1)*r*s1*s1*(lami + 2*mui) + (-1)*r*s1*s1*mui;





//  solve quadratic

       quad(a1r, a1i, a2r, a2i, a3r, a3i, t1r, t1i, t2r, t2i);


//  take square roots (biquadratic equation)

       square(*t1r, *t1i, u1r, u1i);

       square(*t2r, *t2i, u2r, u2i);


//  order the roots  
     
        if ( fabs(*u1r) < fabs(*u2r) )
		{
		  s3pr=*u1r;
          s3pi=*u1i;
          s3sr=*u2r;
          s3si=*u2i;
		}
        else
		{
		  s3pr=*u2r;
          s3pi=*u2i;
          s3sr=*u1r;
          s3si=*u1i;
		}



// calculate the polarisations

       pol(lamr, lami, mur, mui, r, s1, s3pr, s3pi, epr, epi);

       pol(lamr, lami, mur, mui, r, s1, s3sr, s3si, esr, esi);

// normalize the eigenvalues

       norm = epr[0]*epr[0] + epr[1]*epr[1] + epi[0]*epi[0] + epi[1]*epi[1];

       norm=sqrt(norm);

       epr[0]=epr[0]/norm;
       epr[1]=epr[1]/norm;
       epi[0]=epi[0]/norm;
       epi[1]=epi[1]/norm;

       norm = esr[0]*esr[0] + esr[1]*esr[1] + esi[0]*esi[0] + esi[1]*esi[1];

       norm=sqrt(norm);

       esr[0]=esr[0]/norm;
       esr[1]=esr[1]/norm;
       esi[0]=esi[0]/norm;
       esi[1]=esi[1]/norm;

// check sign convention on polarisation vectors.

       if ( epr[0] < 0)  
	   {
		 epr[0]=-1*epr[0];
         epr[1]=-1*epr[1];
         epi[0]=-1*epi[0];
         epi[1]=-1*epi[1];
	   };


       if ( esr[0] < 0) 
	   {
		 esr[0]=-1*esr[0];
         esr[1]=-1*esr[1];
         esi[0]=-1*esi[0];
         esi[1]=-1*esi[1];
	   }




// calculate impedence matrices for lower medium

       xr[0][0]= epr[0];
       xr[0][1]= esr[0];


       xi[0][0]= epi[0];
       xi[0][1]= esi[0];

       *t1r= (lamr + 2*mur)*epr[1] - (lami + 2*mui)*epi[1];
       *t1i= (lami + 2*mui)*epr[1] + (lamr + 2*mur)*epi[1];

       *t2r= (*t1r)*s3pr - (*t1i)*s3pi;
       *t2i= (*t1i)*s3pr + (*t1r)*s3pi;

       xr[1][0] = -1*( (*t2r) + s1*lamr*epr[0] + (-1)*s1*lami*epi[0] );

       xi[1][0] = -1*( (*t2i) + s1*lamr*epi[0] + s1*lami*epr[0] );


       *t1r = (lamr + 2*mur)*s3sr - (lami + 2*mui)*s3si;
       *t1i = (lamr + 2*mur)*s3si + (lami + 2*mui)*s3sr;

       *t2r = (*t1r)*esr[1] - (*t1i)*esi[1];
       *t2i = (*t1r)*esi[1] + (*t1i)*esr[1];

       xr[1][1] = -1*(s1*lamr*esr[0] + (-1)*s1*lami*esi[0] + (*t2r));

       yr[1][0] = epr[1];
       yi[1][0] = epi[1];
       yr[1][1] = esr[1];
       yi[1][1] = esi[1];

       *t1r = s3pr*epr[0] - s3pi*epi[0];
       *t1i = s3pi*epr[0] + s3pr*epi[0];

       *t2r = s1*epr[1] + (*t1r);
       *t2i = s1*epi[1] + (*t1i);

       yr[0][0] = -1*(mur* (*t2r) - mui* (*t2i));
       yi[0][0] = -1*(mur* (*t2i) + mui* (*t2r));

       *t1r = s3sr*esr[0] - s3si*esi[0];
       *t1i = s3sr*esi[0] + s3si*esr[0];

       *t2r = s1*esr[1] + (*t1r);
       *t2i = s1*esi[1] + (*t1i);

       yr[0][1] = -1*(mur*(*t2r) - mui*(*t2i));
       yi[0][1] = -1*(mur*(*t2i) + mui*(*t2r));

//  calculate inverses

       rinv(xp, xpin);
       rinv(yp, ypin);

//  calculate reflection matrix

 
       rmult(xpin, xr, t1);
       rmult(ypin, yr, t2);
       rsubt(t1, t2, m1r);
       rmult(xpin, xi, t1);
       rmult(ypin, yi, t2);
       rsubt(t1, t2, m1i);

       rmult(xpin, xr, t1);
       rmult(ypin, yr, t2);
       radd(t1, t2, wr);
       rmult(xpin, xi, t1);
       rmult(ypin, yi, t2);
       radd(t1, t2, wi);

       dcinv(wr, wi, m2r, m2i);

       dcmult(m1r, m1i, m2r, m2i, refr, refi);


       phase[index]= atan2( refi[0][0], refr[0][0]);

       amp[index] = sqrt( refr[0][0]*refr[0][0] + refi[0][0]*refi[0][0] );
 
       if (phase[index] > 1.57)  
       amp[index]=-1*amp[index];

	}

	FILE *fpWrite=fopen("pp.dat","w");
	if(fpWrite==NULL)
	{
		return 0;
	}
	for(int i=0;i<90;i++)
	fprintf(fpWrite,"%f  %f\n",deg[i],amp[i]);
	fclose(fpWrite);

	free(t1r);t1r = NULL ;
	free(t1i);t1i = NULL ;
	free(t2r);t2r = NULL ;
	free(t2i);t2i = NULL ;
	free(u1r);u1r = NULL ;
	free(u1i);u1i = NULL ;
	free(u2r);u2r = NULL ;
	free(u2i);u2i = NULL ;

	return 0;

}
	   
       
	   	   
	   
	   
/**************sub functions definition**************/
void avo_rp(double w, double vp0, double vs0, double f0, double r, double por0, double cd0, double tau,complex& lfw, complex& mfw)
{

   double  kf0;

   double  ar0, af0;

   double  mu, lam, lc, mc, freq, por;

   double  kf, cd, ar, af, zero;
   
   double  cla, cmu;

   complex c11, c12, c13, c33, c44;

   zero=0;

// define the reference parameters
   vp0 = 4.750;
   vs0 = 3.086;
   f0  = 10;
   r   = 2.56;
   por0= .05;
   cd0 = 0.40;
   tau = 1e-3;
   
// fluid bulk modulus for water (GPa)
   kf0 = 2;
   af0 = 1;

// calculate the common elastic moduli

   mu  = vs0*vs0*r;
   lam = vp0*vp0*r - 2*mu;

   fdc(lam, mu, r, zero, af0, cd0, por0, kf0, tau, f0, c11, c33, c12, c13, c44);

   lc = 2*lam - c12.r;
   mc = 2*mu - c44.r;

// define the varying parameters

   freq= w;
   por = por0;
// varying fluid bulk modulus for fluid substitution (GPa)
   kf  = 0.02;
   cd  = cd0;
   af  = af0;

// calculate the final elastic modulus

   fdc(lam, mu, r, zero, af, cd, por, kf, tau, w, c11, c33, c12, c13, c44);

   cla = lc - lam;
   //cmplx(lc - lam, 0, cla);

   cmu = mc - mu;

   lfw = c12 + cla;

   mfw = c44 + cmu;

   return;
}



void pol(double lamr, double lami, double mur, double mui, double r, double s1, double s3r, double s3i, double er[2], double ei[2])
{
   double ar, ai, br, bi;

   double cr, ci, dr, di, norm1, norm2;


// define the christoffel matrix.

   ar = (lamr + 2*mur)*s1*s1 + mur*s3r*s3r + (-1)*mur*s3i*s3i + (-2)*mui*s3r*s3i - r;

   ai = (lami + 2*mui)*s1*s1 + mui*s3r*s3r + (-1)*mui*s3i*s3i + 2*mur*s3r*s3i;

   br = s1*s3r*(lamr + mur) + (-1)*s1*s3i*(lami + mui);

   bi = s1*s3i*(lamr + mur) + s1*s3r*(lami + mui);

   cr = br;

   ci = bi;

   dr = s1*s1*mur + (lamr + 2*mur)*s3r*s3r + (-1)*(lamr + 2*mur)*s3i*s3i + (-2)*(lami + 2*mui)*s3r*s3i - r;

   di = s1*s1*mui + (lami + 2*mui)*s3r*s3r + (-1)*(lami + 2*mui)*s3i*s3i + 2*(lamr + 2*mur)*s3i*s3r;

// choose the row with the largest entries

   norm1= (ar*ar + ai*ai + br*br + bi*bi);

   norm2= (cr*cr + ci*ci + dr*dr + di*di);

// calculate polarisations

   if (norm1 > norm2){
	 er[0] = br;
     er[1] = -1*ar;
     ei[0] = bi;
     ei[1] = -1*ai;
   }else{
	 er[0] = dr;
     er[1] = -1*cr;
     ei[0] = di;
     ei[1] = -1*ci;
   }
   return;
}
       




void radd(double a[2][2], double b[2][2], double c[2][2])
{
	c[0][0] = a[0][0] + b[0][0];
    c[0][1] = a[0][1] + b[0][1];
    c[1][0] = a[1][0] + b[1][0];
    c[1][1] = a[1][1] + b[1][1];
	return;
}


void rsubt(double a[2][2], double b[2][2], double c[2][2])
{
   c[0][0] = a[0][0] - b[0][0];
   c[0][1] = a[0][1] - b[0][1];
   c[1][0] = a[1][0] - b[1][0];
   c[1][1] = a[1][1] - b[1][1];
   return;
}


void rmult(double a[2][2], double b[2][2], double c[2][2])
{
   c[0][0] = a[0][0]*b[0][0] + a[0][1]*b[1][0];
   c[0][1] = a[0][0]*b[0][1] + a[0][1]*b[1][1];
   c[1][0] = a[1][0]*b[0][0] + a[1][1]*b[1][0];
   c[1][1] = a[1][0]*b[0][1] + a[1][1]*b[1][1];

   return;
}

void rinv(double a[2][2], double b[2][2])
{
  double det;
   det = (a[0][0]*a[1][1]) - (a[0][1]*a[1][0]);
   b[0][0] = a[1][1]/det;
   b[0][1] = -1*a[0][1]/det;
   b[1][0] = -1*a[1][0]/det;
   b[1][1] = a[0][0]/det;

return; 
   
}



void square(double ar, double ai, double *br, double *bi)
{
//  this subroutine takes a complex number ar + i*ai and returns its
//  square root in the form br+i*bi. it follows the technique suggested
//  on page 172 of numerical recipes. written by mark chapman, 2004.

  double w, temp1, temp2;

  if ( ar < (-1e-8) && fabs(ai) < (1e-8) ) {
	   *br=0;
      *bi=sqrt(fabs(ar));
  }else{
      if ( fabs(ar)<(1e-8) && fabs(ai)<(1e-8) )
         w=0;
      else{
           if  ( fabs(ar) >= fabs(ai)){
			   temp1= 1 + sqrt(1 + (ai*ai)/(ar*ar));
              temp1= sqrt( 0.5* temp1);
              temp2= sqrt(fabs(ar));
              w = temp1*temp2;
			}else{
			   temp1= sqrt(1 + (ar*ar)/(ai*ai) );
              temp1= fabs(ar/ai) + temp1;
              temp1= sqrt(0.5*temp1);
              temp2= sqrt(fabs(ai));
              w= temp1*temp2;
			}
	   }
  }

   if ( fabs(w) < 1e-8) {  
	   *br=0;
      *bi=0;
	  }else{
      if (ar >= 0){
		*br=w;
       *bi=(ai/(2*w));
	   }else{
		  if (ai >= 0){
			*br=fabs(ai)/(2*w);
            *bi=w;
		   }
          if (ai < 0){
			 *br=fabs(ai)/(2*w);
            *bi=-1*w;
		   }
	   }
	}

  return;

}


void quad(double ar, double ai, double br, double bi, double cr, double ci, double *xr, double *xi, double *yr, double *yi)
{
//  this is a double precision programme for solving the complex
//  valued quadratic equation az^2 + bz + c =0
//  inputs are a=(ar,ai) etc. no ordering applied to the roots.
//  written by mark chapman, 2004.


   double ur, ui, vr, vi, error;

   double *dr, qr, qi, temp1, temp2;
   
   double *di;

// calculate square root of discriminant
   dr =(double *)malloc(1 * sizeof(double));
   di =(double *)malloc(1 * sizeof(double));
   if (dr == NULL || di==NULL ) {    //判断是否为空
       printf("Error in allocating memory.");
       exit(1);
    }

   temp1 = br*br + (-1)*bi*bi + (-1)*4*ar*cr + 4*ai*ci;

   temp2 = 2*br*bi + (-4)*ar*ci + (-4)*ai*cr;

   square(temp1, temp2, dr, di);



// calculate q value, following numerical recipes p.178

   if ( (br* (*dr) + bi* (*di)) >= 0 ) 
   {
      qr = br + *dr;
      qr = -0.5*qr;
      qi = bi + *di;
      qi = -0.5*qi	;	   
   }else{
      qr = br - *dr;
      qr = -0.5*qr;
      qi = bi - *di;
      qi = -0.5*qi;
	}


//  now calculate roots

   temp1 = ar*ar + ai*ai;

   *xr = (qr*ar + qi*ai)/temp1;
   *xi = (-1*qr*ai + qi*ar)/temp1;

   temp2 = qr*qr + qi*qi;

   *yr = (cr*qr + ci*qi)/temp2;
   *yi = (ci*qr - cr*qi)/temp2;

   free(dr);dr = NULL;
   free(di);di = NULL;
   return ;

}



   
	   
void dcinv(double x[2][2], double y[2][2], double a[2][2], double b[2][2])
{
	double  detr, deti, mr, mi;

    double  t1[2][2], t2[2][2];

//  this code inverts a 2X2 complex matrix, x+iy, where x and y are
//  2x2 double precision real matrices and returns the inverse
//  as a+ib, a and b being double precision 2X2 matrices. 
//  written by mark chapman 2004.

    detr = x[0][0]*x[1][1] + (-1)*y[0][0]*y[1][1] + (-1)*x[0][1]*x[1][0] + y[0][1]*y[1][0];

    deti = x[0][0]*y[1][1] + y[0][0]*x[1][1] + (-1)*x[0][1]*y[1][0] + (-1)*x[1][0]*y[0][1];

    mr= detr/(detr*detr + deti*deti);

    mi= (-1*deti)/(detr*detr + deti*deti);

   t1[0][0]= x[1][1];
   t1[0][1]= -1*x[0][1];
   t1[1][0]= -1*x[1][0];
   t1[1][1]= x[0][0];

   t2[0][0]= y[1][1];
   t2[0][1]= -1*y[0][1];
   t2[1][0]= -1*y[1][0];
   t2[1][1]= y[0][0];

   a[0][0]= mr*t1[0][0] - mi*t2[0][0];
   a[0][1]= mr*t1[0][1] - mi*t2[0][1];
   a[1][0]= mr*t1[1][0] - mi*t2[1][0];
   a[1][1]= mr*t1[1][1] - mi*t2[1][1];

   b[0][0]= mi*t1[0][0] + mr*t2[0][0];
   b[0][1]= mi*t1[0][1] + mr*t2[0][1];
   b[1][0]= mi*t1[1][0] + mr*t2[1][0];
   b[1][1]= mi*t1[1][1] + mr*t2[1][1];

   return;
}
	   

	   

void dcmult(double a[2][2], double b[2][2], double u[2][2], double v[2][2], double x[2][2], double y[2][2])
{

    double  t1[2][2], t2[2][2];

//  this subroutine takes in 2X2 complex matrices (a+ib)
//  and (u+iv), double precision and returns the product
//  (a+ib)(u+iv) = (x+iy).
//  written by mark chapman 2004.

    rmult(a, u, t1);
    rmult(b, v, t2);
    rsubt(t1, t2, x);
    rmult(a, v, t1);
    rmult(b, u, t2);
    radd(t1, t2, y);

   return;

}
	   


void fdc(double lam, double mu, double rho, double fd, double af, double cd, double ppor, double kf, double tau, double w, complex& c11, complex& c33, complex& c12, complex& c13, complex& c44) 
{
//  This subroutine takes real values for the lamee constants (lam & mu), the density (rho) fracture 
//  density (fd), fracture length in meters (af), the microcrack density (cd), the porosity (ppor)
//  the parameter gamma (gam) related to fluid compressibility, the time constant (tau) related to the
//  inverse of the squirt flow frequency and the wave frequency (w). 

//  The output is a complex elastic tensor, with the x_3 axis assumed to be the axis of symmetry. This 
//  elastic tensor is characterised by the constants c11, c33, c12, c13 and c44.


   double cpor, fpor, beta, io;
   double tauf, gam, gamp, kc, ar, v, pi, crit, l2, l3;
   double po;
   double pr;

   complex i1, c66, kap;

   complex a, b, c, z1, z2, z3, z4, z5, z6, z7, z8, z9;

   complex d1, d2, f1, f2, g1, g2, g3, vel, f;

   complex aa1, aa2, aa3, aa4, aa5, aa6, bb1, bb2, bb3, bb4, bb5;

   complex jj1, jj2, jj3, jj4, kk1, kk2, kk3, kk4, kk5, kk6;

   complex mm1, mm2, mm3, mm4, mm5, mm6;

   complex x1, x2, x3, v1, v2, v3;

   int j, k, l;

   //i=(0,1)
	i1.r=0.0; i1.i=1.0;
//   parameter values


   ar=1E-3;
   gamp=1;
   tauf=5000*af*tau;


   cpor=4.187*cd*ar;
   fpor=4.187*fd*ar;


//   some definitions


   po=(((lam+2*mu)/rho) - 2*(mu/rho))/(2*((lam+2*mu)/rho) - (mu/rho));


   gam=(1.18*( 1 + (1.3333333)*((mu)/(kf))))/(1-po);

   pi=3.1415926535;

   l2=(lam*lam) + (1.33333333*lam*mu) +(0.8*mu*mu);

   l3=4*(lam*lam + (1.33333*lam*mu) + (0.5333333*mu*mu) );

   v=lam/(2*(lam+mu));

   kap=lam+ (0.66666666*mu);


   crit=(pi*mu*ar)/(2-2*v);

   io=(cpor/ar)/( (cpor/ar) + ppor);


   kc=(pi*mu*ar)/(2*(1-v)*kf);

   beta=(fpor/ar)/((cpor/ar) + ppor);


// calculate d1 and d2, f1 and f2


   z1=(io/(3 + 3*kc)) + (gamp - gamp*io);
   z2=((i1*w*tau)*( 1/(3 + 3*kc) -gamp))/(1+i1*w*tau);


   z3=io +( (io*beta)/(1+i1*w*tauf));

   a=z1 - (z2*z3);

   b=beta/( (1+kc)*(1+i1*w*tauf) );


   z4=((1-io)*gam) + (( (1-io)*beta)/(1+i1*w*tauf));
   z5=(io + ((io*beta)/(1 + i1*w*tauf)))*((1+i1*w*gam*tau)/(1+i1*w*tau));
   
   c= z4 + z5;



   d1=a/c;



   d2=b/c;




   x1=io*d1*(1+i1*w*gam*tau)/(1+i1*w*tau);
   x2= d1*(1-io);
   x3=(((1/(3 + 3*kc)) -gamp)*io*i1*w*tau)/(1+i1*w*tau);

   f1=(x1 + x2 + x3)/(1 + i1*w*tauf);



   v1=(i1*w*tauf)/(1 + kc);
   v2=(io*d2*(1+i1*w*gam*tau))/(1+i1*w*tau);
   v3=d2*(1-io);


   f2=(v1+v2+v3)/(1+i1*w*tauf);


// end definiton of d1, d2, f1, f2

// define g1, g2, g3


  
   g1=(i1*w*tau)/( (1+i1*w*tau)*(1+kc));


   g2=(d1 +(d1*i1*w*tau*gam) - (gamp*i1*w*tau))/(1+i1*w*tau);


   g3=(d2*(1+i1*w*gam*tau))/(1+i1*w*tau);



// end of definition of g1, g2, g3

// calculation of c_11


   aa1=(l2/crit) + ((32*(1-v)*mu)/(15*(2-v)*pi*ar));

   aa2=(((l2/crit)+kap)*g1) + ((((3*kap*kap)/crit) +3*kap)*g2) + ( (((lam*kap)/crit)+lam)*g3);


// crack correction cpor*(aa1-aa2)



   aa3=( (3*lam*lam + 4*lam*mu+ (mu*mu*(36+20*v)/(7-5*v)) )*3*(1-v))/(4*(1+v)*mu);

   aa4=(1+(3*kap)/(4*mu))*(3*kap*d1 + lam*d2);



// porosity correction ppor*(aa3-aa4)

   aa5=lam*lam/crit;

   aa6=((3*lam*kap/crit)+(3*kap))*f1 + ( ( (lam*lam/crit) + lam)*f2);


// fracture correction fpor*(aa5-aa6)

   c11= (lam+2*mu) + ((-1)*cpor*(aa1-aa2)) + ((-1)*ppor*(aa3-aa4)) + ((-1)*fpor*(aa5-aa6));

// calculation of c33

   bb2=(((l2/crit)+kap)*g1) + ((((3*kap*kap)/crit) +3*kap)*g2) + (((((lam+2*mu)*kap)/crit)+(lam+2*mu))*g3);


// crack correction cpor*(aa1-bb2)

   bb3=(1+((3*kap)/(4*mu)))*( (3*kap*d1) + ((lam+2*mu)*d2) );

   
// porosity correction ppor*(aa3-bb3)

   bb4=(lam +2*mu)*(lam+2*mu)/crit;

   bb5=(( (3*kap*(lam+2*mu)/crit) +3*kap)*f1) + f2*( ((lam+2*mu)*(lam+2*mu)/crit) + lam + 2*mu);



// fracture correction fpor*(bb4-bb5)


   c33 = (lam+2*mu) + ((-1)*cpor*(aa1-bb2)) + ((-1)*ppor*(aa3-bb3)) + ((-1)*fpor*(bb4-bb5));


// calculation of c44


   jj1=(0.2666666666667)*mu*mu*(1-g1)/crit;

   jj2=((1.6)*(1-v)*mu)/(pi*ar*(2-v));

// crack correction cpor*(jj1 + jj2)



   jj3=(15*(1-v)*mu)/(7-5*v);

// porosity correction ppor*jj3

   vel=ppor*jj3;

   jj4=(4*(1-v)*mu)/(pi*(2-v)*ar);

// fracture correction fpor*jj4


   vel=fpor*jj4;

   c44 = mu + ((-1)*cpor*(jj1+jj2)) + ((-1)*ppor*jj3) + ((-1)*fpor*jj4);


// calculation of c12

   kk1=(l3/crit) + ((32*(1-v)*mu)/(15*(2-v)*pi*ar));

   kk2=(((l3/crit) + 4*kap)*g1) + (((12*kap*kap/crit) + 12*kap)*g2) + (((4*lam*kap/crit) + 4*lam)*g3);

// crack correction cpor*(kk1-kk2)

   kk3= ((12*lam*lam + 16*lam*mu +(mu*mu*64/(7-5*v)))*3*(1-v))/(4*(1+v)*mu);


   kk4=( (1.5*kap/mu) + 2)*(6*kap*d1 + 2*lam*d2);


// porosity correction ppor*(kk3-kk4)


   kk5=4*lam*lam/crit;

   kk6=(f1*( (12*kap*lam/crit) + 12*kap)) + (f2*( (4*lam*lam/crit) + 4*lam));

// fracture correction fpor*(kk5-kk6)

   c12 =0.5*( (4*lam+4*mu) + ((-2)* c11) + ((-1)*cpor*(kk1-kk2)) + ((-1)*ppor*(kk3-kk4)) + ((-1)*fpor*(kk5-kk6)) );


// calculation of c13

   mm2=(((l3/crit) + 4*kap)*g1) + (((12*kap*kap/crit) + 12*kap)*g2)+(((4*(lam+mu) *kap/crit) + 4*(lam+mu))*g3);

// crack correction cpor*(kk1-mm2)

   mm4=( (1.5*kap/mu) + 2)*(6*kap*d1 + (2*lam+2*mu)*d2);

// porosity correction ppor*(kk3-mm4)

   mm5=(4*(lam+mu)*(lam+mu))/crit;

   mm6=(f1*( (12*kap*(lam+mu)/crit) + 12*kap)) + (f2*( (4*(lam+mu)*(lam+mu)/crit) + 4*(lam+mu)));

// fracture correction fpor*(mm5-mm6)


   c13 = 0.5*( (4*lam+4*mu) + ((-1)*( c11 + c33)) + ((-1)*cpor*(kk1-mm2)) + ((-1)*ppor*(kk3-mm4)) + ((-1)*fpor*(mm5-mm6)) );


   return;
	   
}



