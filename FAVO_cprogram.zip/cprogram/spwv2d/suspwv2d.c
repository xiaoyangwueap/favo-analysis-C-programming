/************************************
 * British Geological Survey, 2016  *
 * Gareth Williams                  *
 * SUSPWV2D Revision: 1.00          *
 * Date: 11/2016                    *
 ***********************************/

#include "su.h"
#include "segy.h"
#include "header.h"

char *sdoc[] = {
  "\nSUSPWV2D - iso-frequency section using the smoothed pseudo-Wigner transform",
  "------------------------------------------------------------------------------\n",
  "suspwv2d [parameters] < stdin > stdout\n",
  "Parameters:\n",
  "\tverbose=0\t\t=1 for verbose",
  "\tdt=(from header)\tTime sampling rate (s)",
  "\thwin=nfft/4\t\tH smoothing window (samples)",
  "\tgwin=nfft/10\t\tG smoothing window (samples)",
  "\tfrout=30.0\t\toutput frequency in Hz\n",
  "Notes:\n",
  "\t1)The smoothed pseudo-Wigner transform is given by:\n",
  "\t\tW(t,f) = Integral h*(tau) Integral g(tau) [s(t+t*/2)s*(t-t*/2)*exp(-iwt)]*dt\n",
  NULL
};

/* 
For a signal, s(t), with analytic associate x(t), the Wigner-Ville Distribution, 
Wx(t,ω) is defined as:

	W(t,f) = Integral h*(tau) Integral g(tau) [s(t+t'/2)s*(t-t'/2)*exp(-iwt)]*dt

In general the 'Wigner Distribution' of a signal x(t) is defined as above, 
while the 'Wigner-Ville Distribution' is defined as the Wigner Distribution 
where x(t) is the analytic associate (or "complex signal") of s(t). The analytic 
associate x(t) of a signal s(t) is defined as: 
  x(t)=s(t)+iH[s(t)], 

where H[s(t)] is the Hilbert Transform of the signal s(t); the Hilbert Transform 
is sometimes referred to as a "quadrature filter" and the transformed signal as 
the "quadrature signal," for reasons relating to the phase shifts introduced by 
the transform -- running the transform four times will return the signal to the 
original signal, as each transformation shifts real frequencies by π/2 and 
negative frequencies by -π/2.

For the W-V spectrum, you can theoretically create a distribution 
with as many points in the time domain as there are in the original time series, 
while simultaneously having the same resolution in the frequency domain! 
The trade-offs include: artifacts along frequency axis from harmonics or more 
than one peak; the generation of negative energy and artifacts along time axis 
if you have multiple "events" in time... say an earthquake and an aftershock 
in the same record, or even multiple phases arriving from the same event.

ANALYTIC SIGNAL: Signal with Fourier transform equal to 0 for frequencies lower 
than 0. This is a desirable property when the Wigner-Ville is computed. However, 
most practical signals are real, a condition which implies a negative frequency 
component for each positive frequency component, and so they are not analytic 
signals. An analytic signal z(t) can be generated from a real signal s(t) 
suppressing the negative frequency components while preserving the positive 
components as:

		z(t) = s(t) + i H[s(t)]

where H[*] is the Hilbert transform operator, and i2 = -1.

The smoothed pseudo-Wigner distribution is given by:

            /        /                                  -j2pi f tau
SPWV(t,f) = | h(tau) | g(tau-t) x(mu+tau/2)x*(mu-tau/2)e          dmu dtau
            /         /
suspike nt=500 dt=0.002 ntr=1 nspk=4 ix1=1 ix2=1 ix3=1 ix4=1 it1=100 it2=200 it3=300 it4=400 \
| sutvband tf=0.2,0.4,0.6,0.8 f=50,55,65,70 f=40,45,55,60, f=30,35,45,50, f=20,25,35,40 \
| dsusspwvtfd2 \
| suximage cmap=hsv2 &
*/


/* globals */
#define LOOKFAC	2               /* Look ahead factor for npfaro. */
#define PFA_MAX	720720          /* Largest allowed nfft. */
segy trin, trout;

float
hanningwin (int n, int k)
{
  float a = 0.50;
  float b = -0.5;
  float pi2;
  float g;

  pi2 = 2.0 * PI;

  if (k > n)
    g = 0.0;
  else
    g = a + b * cos (pi2 * k / (n - 1));

  return g;
}

void
polint0 (float xa[], float ya[], int n, float x, float *y, float *dy)
{
  int i;
  float w1, w2;

  for (i = 1; i < n - 1; i++) {
    if (x == xa[i]) {
      *y = ya[i];
    }
    else if (x > xa[i] && x < xa[i + 1]) {
      w1 = (xa[i + 1] - x) / (xa[i + 1] - xa[i]);
      w2 = (x - xa[i]) / (xa[i + 1] - xa[i]);
      *y = w1 * ya[i] + w2 * ya[i + 1];
      *dy =
        (w1 * ((*y) - ya[1]) + w2 * (ya[i + 1] - (*y))) / (ya[i + 1] - ya[i]);
    }
  }
}

int
main (int argc, char **argv)
{
  FILE *fp;
  register int ntr;             /* trace counter */
  register float *htx;          /* hilbert transformed trace */
  register float *ttx;          /* input time trace */
  register complex *ctx;        /* complex transformed trace */
  register complex *lactx;      /* local autocorrelation */
  float **famp;                 /* t-f spectral */
  int nt=0;                     /* number of points on input trace */
  int nfft;                     /* fft transform length */
  int verbose;                  /* flag to give advisory messages */
  float dt;                     /* Sampling interval in secs */
  float df;                     /* Output sampling interval in Hz */
  float fnyq;                   /* nyquist frequency */

  float htau, gmu;              /* smoothing windows */
  float normG, normH;            /* normalisation factors */
  int windowG, halfwindowG;
  int windowH, halfwindowH;

  float frout, ampout, damp;
  float *freq, *amp;

  /* initialize */
  initargs (argc, argv);
  requestdoc (1);

  /* get parameters from commandline */
  if (!getparint ("verbose", &verbose))
    verbose = 0;
  if (!getparint ("gwin", &windowG))
    windowG = 0;
  if (!getparint ("hwin", &windowH))
    windowH = 0;
  if (!getparfloat ("frout", &frout))
    frout = 30.;

  /* get first trace */
  if (!gettr (&trin))
    err ("can't get first trace");
  else
    nt = trin.ns;

  /* set dt from trace */
  if (!getparfloat ("dt", &dt))
    dt = ((double) trin.dt) / 1000000.0;
  if (!dt) {
    err ("dt not set on trace or in parameter list");
  }

  /* compute pfacc complex-complex fft  parameters */
  nfft = npfao (nt, LOOKFAC * nt);
  if (nfft >= SU_NFLTS || nfft >= PFA_MAX)
    err ("Padded nt=%d--too big", nfft);
  fnyq = 1.0 / (2.0 * dt);
  df = (float) 1.0 / (2 * nfft * dt);   /* frequencies in Hz */

  if (!windowG){
    windowG = (int) nfft / 10;      /* good for seismic data */
    halfwindowG = (int) ((windowG - 1) / 2);
  } else {
    halfwindowG = (int) ((windowG - 1) / 2);
  }

  if (!windowH){
    windowH = (int) nfft / 4;      /* good for seismic data */
    halfwindowH = (int) ((windowH - 1) / 2);
  } else {
    halfwindowH = (int) ((windowH - 1) / 2);
  }

  if (verbose)
    warn ("nfft=%d fnyq=%f df=%f ", nfft, fnyq, df);

  /* allocate memory to arrays */
  ttx = ealloc1float (nt);
  htx = ealloc1float (nt);
  ctx = ealloc1complex (nt);
  lactx = ealloc1complex (nfft);
  famp = ealloc2float (nfft, nt);
  freq = ealloc1float (nfft);
  amp = ealloc1float (nfft);

  /* open debugging file */
  if (!(fp = fopen ("debug.dat", "w"))) {
    perror ("Debug.dat");
  }

  /* constant frequency window normalisation */
  normH = hanningwin (windowH, halfwindowH);

  /* main loop over traces */
  ntr = 0;
  do {
    register int i;
    register int t, tau, taumax;
    register int mu, mumin, mumax;
    register int nspos, nsneg;
    register float tempr1, tempi1, tempr2, tempi2;

    /* increment trace */
    ntr++;

    if (verbose && (ntr % verbose == 0))
      warn ("Processing trace=%d", ntr);

    /* read trace */
    for (i = 0; i < nt; ++i) {
      ttx[i] = trin.data[i];
      htx[i] = 0.0;
    }

    /* take hilbert transform - create an analytic trace ! */
    hilbert (nt, ttx, htx);

    /* build the complex trace */
    for (i = 0; i < nt; ++i) {
      ctx[i] = cmplx (ttx[i], htx[i]);
    }


    /* compute the local autocorrelation function */
    for (t = 0; t < nt; ++t) {

      /* zero array for complex fft prior to windowing */
      for (i=0; i<nfft; i++){
        lactx[i] = cmplx (0.0, 0.0);
      }

      /* compute tau = 0 case */
      tau=0;
      
      /* zero variables for subgs over tau */
      tempr1 = 0.0, tempi1 = 0.0;

      /* determination of the start and end of mu */
      mumin=MIN(halfwindowG,(nt - t - 1));
      mumax=MIN(halfwindowG,t);
    
      /* compute normalisation factor for smoothing window */
      normG = 0.0;
      for(i = -mumin ; i <= mumax ; i++)
      {
        normG = normG + hanningwin (windowG, i);
      }

      for(mu=-mumin;mu<=mumax;mu++)
      {
        /* apply smoothing kernel in mu */
        gmu = hanningwin (windowG, mu+halfwindowG);

        nspos = floor (t + tau - mu);
        nsneg = floor (t - tau - mu);
    
        tempr1 += ((ctx[nspos].r) * (ctx[nsneg].r)
        + (ctx[nspos].i) * (ctx[nsneg].i)) * gmu / normG;

        tempi1 += ((ctx[nspos].i) * (ctx[nsneg].r)
        - (ctx[nspos].r) * (ctx[nsneg].i)) * gmu / normG;      
      }

      /* apply smoothing kernel in tau */
      htau = hanningwin (windowH, halfwindowH+tau);
      tempr1 *= htau / normH;
      tempi1 *= htau / normH;

      /* store LACF as complex signal */
      lactx[tau] = cmplx (tempr1, tempi1);

      /* main loop over trace */
      /* taumax limits the range of tau near the edges */
      taumax = MIN((t+halfwindowG),((nt - t - 1)+halfwindowG));
      taumax = MIN(taumax,(nfft / 2 - 1));
      taumax = MIN(taumax, halfwindowH);

      /* first loop over tau ! */
      for (tau = 1; tau <= taumax; ++tau) {
        /* zero variables for subgs over tau */
        tempr1 = 0.0, tempi1 = 0.0;
        tempr2 = 0.0, tempi2 = 0.0;

        /* determination of the start and end of mu */
        mumin=MIN(halfwindowG,(nt - t - 1 - tau));
        mumax=MIN(halfwindowG,t - tau);

        /* compute normalisation factor for smoothing window */
        normG = 0.0;
        for(i = -mumin; i <= mumax ; i++)
        {
          normG = normG + hanningwin (windowG, i);
        }
  
        for(mu=-mumin;mu<=mumax;mu++)
        {
          /* apply smoothing kernel in mu */
          gmu = hanningwin (windowG, mu+halfwindowG);

          nspos = floor (t + tau - mu);
          nsneg = floor (t - tau - mu);
      
          tempr1 += ((ctx[nspos].r) * (ctx[nsneg].r)
          + (ctx[nspos].i) * (ctx[nsneg].i)) * gmu / normG;

          tempi1 += ((ctx[nspos].i) * (ctx[nsneg].r)
          - (ctx[nspos].r) * (ctx[nsneg].i)) * gmu / normG;

          tempr2 += ((ctx[nsneg].r) * (ctx[nspos].r)
          + (ctx[nsneg].i) * (ctx[nspos].i)) * gmu / normG;

          tempi2 += ((ctx[nsneg].i) * (ctx[nspos].r)
          - (ctx[nsneg].r) * (ctx[nspos].i)) * gmu / normG; 
        }

        /* apply smoothing kernel in tau */
        htau = hanningwin (windowH, halfwindowH+tau);
        tempr1 *= htau / normH;
        tempi1 *= htau / normH;
        htau = hanningwin (windowH, halfwindowH-tau);
        tempr2 *= htau / normH;
        tempi2 *= htau / normH;

        /* store LACF as complex signal */
        lactx[tau] = cmplx (tempr1, tempi1);
        lactx[nfft-tau] = cmplx (tempr2, tempi2);
      }

      /* compute tau = nfft / 2 */
      tau=floor(nfft / 2);
      if ((t <= t-tau-1)&(t >= tau)& (tau <= halfwindowH))
      {
        /* zero variables for subgs over tau */
        tempr1 = 0.0, tempi1 = 0.0;
        tempr2 = 0.0, tempi2 = 0.0;

        /* determination of the start and end of mu */
        mumin=MIN(halfwindowG,(nt - t - 1 - tau));
        mumax=MIN(halfwindowG,t - tau);

        /* compute normalisation factor for smoothing window */
        normG = 0.0;
        for(i = -mumin ; i <= mumax ; i++)
        {
          normG = normG + hanningwin (windowG, i);
        }
  
        for(mu=-mumin;mu<=mumax;mu++)
        {
          /* apply smoothing kernel in mu */
          gmu = hanningwin (windowG, mu+halfwindowG);

          nspos = floor (t + tau - mu);
          nsneg = floor (t - tau - mu);
      
          tempr1 += ((ctx[nspos].r) * (ctx[nsneg].r)
          + (ctx[nspos].i) * (ctx[nsneg].i)) * gmu / normG;

          tempi1 += ((ctx[nspos].i) * (ctx[nsneg].r)
          - (ctx[nspos].r) * (ctx[nsneg].i)) * gmu / normG;

          tempr2 += ((ctx[nsneg].r) * (ctx[nspos].r)
          + (ctx[nsneg].i) * (ctx[nspos].i)) * gmu / normG;

          tempi2 += ((ctx[nsneg].i) * (ctx[nspos].r)
          - (ctx[nsneg].r) * (ctx[nspos].i)) * gmu / normG; 
        }

        /* apply smoothing kernel in taus */
        htau = hanningwin (windowH, halfwindowH+tau);
        tempr1 *= htau / normH;
        tempi1 *= htau / normH;
        htau = hanningwin (windowH, halfwindowH-tau);
        tempr2 *= htau / normH;
        tempi2 *= htau / normH;

        /* store LACF as complex signal */
        lactx[tau] = cmplx (0.5*(tempr1+tempr2), 0.5*(tempi1+tempi2));
      }

      /* seismic unix complex fourier transform routine */
      pfacc (1, nfft, lactx);

      for (i = 0; i < nfft; i++) {
        famp[t][i] = sqrt ((lactx[i].r * lactx[i].r) \
        + (lactx[i].i * lactx[i].i));
      }

      /* populate amplitude and frequency arrays */
      for (i = 0; i < nfft; ++i) {
        freq[i] = ((float) i) * df;
        amp[i] = famp[t][i];
      }

      for (i = 0; i < nfft; ++i) {
        if (frout == freq[i]) {
          trout.data[t] = amp[i];
        }
        else if (frout <= freq[i + 1] && frout > freq[i]) {
          polint0 (freq, amp, nfft, frout, &ampout, &damp);
          trout.data[t] = ampout;
        }
      }
    }

    /* copy header from input trace to output trace */
    memcpy ((void *) &trout, (const void *) &trin, HDRBYTES);

    trout.tracr = (int) ntr;
    trout.tracl = (int) ntr;
    trout.d1 = (float) dt;
    trout.ns = (int) nt;

    puttr (&trout);

  } while (gettr (&trin));

  /* close debugging file */
  fclose (fp);

  return EXIT_SUCCESS;
}
