/************************************
 * British Geological Survey, 2019  *
 * Xiaoyang Wu                      *
 * SUFAVOINV Version: 1.00          *
 * Date: 06/2019                    *
 ***********************************/

#include "su.h"
#include "segy.h" 
#include "header.h"
#include "stdlib.h"
#include "math.h"
#include "stdio.h"
/*********************** self documentation ******************************/
char *sdoc[] = {
"																			",
" SUFAVOINV -  Frequency-dependent AVO inversion using spwvd				",
"																			",
" sufavoinv inSD0=file0 inSD1=file1 inSD2=file2 inSD3=file3 inSD4=file4		",
" inSD5=file5 inVP=file6 > stdout [optional parameters]						",
"																			",
" Required Parameters:														",
" inSD0=	input original seismic data volume:.su							",
" inSD1=	input spectral data volume for first(reference)frequency:.su	",
" inSD2=	input spectral data volume for second frequency:.su				",
" inSD3=	input spectral data volume for third frequency:.su				",
" inSD4=	input spectral data volume for fourth frequency:.su				",
" inSD5=	input spectral data volume for fifth frequency:.su				",
" inVP=	    input spectral data volume for p-wave velocity:.dat				",
"																			",
" Optional parameters:														",
" ns=                   number of samples in each trace						",
" ntraces=              number of traces in each CMP gather					",
" ncmp=                 number of CMP gather in the data volume				",
" startcmp=            the value of the first CMP key						",
"                       for the fast shear wave on the output volumes		",
" freq=                 spectral decomposing frequencies, the first			",
"                       one should be the reference frequency, other		",
"                       frequencies are listed in ascending order.			",
" minoffset=           the minimum offset for in the gather					",
"                       miliseconds the fast and slow shear components		",
" trspace=          trace space between two neighbouring traces				",
" dt=		            time sampling rate									",
" startpoint=          the sampling point starting for favo calculation		",
" win1=      start time of the reference window for spectral balancing		",
" win2=      end time of the reference window for spectral balancing		",
"																			",
" Notes:																	",
" This function computes the frequency dependent AVO attribute				",
" using spwv spectral decomposition method. The input seismic dataset		",
" must be interpolated to have the same number of traces and offsets,		",
" and sorted into ensemble gathers defined by CDP number.					",
" The input su files include 1 original seismic amplitude data and 5		",
" spectral amplitude seismic data.											",
NULL};

/**************** end self doc *******************************************/



/* Global variables */
float **inSD0_gthr, **inSD1_gthr, **inSD2_gthr;  //store cdp gather data
float **inSD3_gthr, **inSD4_gthr, **inSD5_gthr;
segy inSD0_tr, inSD1_tr, inSD2_tr;
segy inSD3_tr, inSD4_tr, inSD5_tr;
segy outtr;


/* function prototypes */
FILE *open_vol(cwp_String vol_name, int *ns, float *dt, segy *tr);
FILE *read_velocity(char *filename, int ns, float *vp);
void matrix_tranpose(float **a, int krow, int kline, float **b);
void matrix_multiplication(float **a, float **b, int m, int n, int k, float **c);
int rinv(float **a,int n);
int getgather(FILE *fp, int ntraces,float **cdptraces);


int main(int argc, char **argv)
{
	float **Dp=NULL,**B1=NULL;  /* the gather data for respective volumes */
	float **B2=NULL,**B3=NULL;
	float **B4=NULL,**B5=NULL;
	float **D1b=NULL,**D2b=NULL,**D3b=NULL,**D4b=NULL,**D5b=NULL;
	float *vp=NULL, *vs=NULL;    /* vp from input file*/
	float *m1=NULL,*m2=NULL,*m3=NULL,*m4=NULL,*m5=NULL;
	float *a2IF=NULL, *a3IF=NULL, *a4IF=NULL, *a5IF=NULL;
	float *dd=NULL,*bb1=NULL,*bb2=NULL,*bb3=NULL,*bb4=NULL,*bb5=NULL;
	float *plfref=NULL, *pdd2ref=NULL, *slfref=NULL;
	
	float *twt=NULL, *h=NULL, *x=NULL;
	float **theta = NULL;
	float **pvel = NULL;
	float **svel = NULL;
	
	cwp_String inSD0="";	/* input SD0 volume file name		*/
	cwp_String inSD1="";	/* input SD1 volume file name		*/
	cwp_String inSD2="";	/* input SD2 volume file name		*/
	cwp_String inSD3="";	/* input SD3 volume file name		*/
	cwp_String inSD4="";	/* input SD4 volume file name		*/
	cwp_String inSD5="";	/* input SD5 volume file name		*/
	cwp_String inVP="";     /* input vp file name               */

	FILE *SD0fp=NULL;	/* input SD0 file pointer 		*/
	FILE *SD1fp=NULL;	/* input SD1 file pointer		*/
	FILE *SD2fp=NULL;	/* input SD2  file pointer 		*/
	FILE *SD3fp=NULL;	/* input SD3 file pointer		*/
	FILE *SD4fp=NULL;	/* input SD4 file pointer 		*/
	FILE *SD5fp=NULL;	/* input SD5 file pointer		*/
	FILE *VPfp=NULL;	/* input vp file pointer 		*/

	FILE *fp0=NULL,*fp1=NULL,*fp2=NULL,*fp3=NULL,*fp4=NULL,*fp5=NULL;	
	cwp_String key = "cdp";      /* keys used to read the desired gather */
	cwp_String key_type = hdtype(key);
	
	int ns;  /* number of points on trace for volumes */
	int ntraces;		/* number of traces to enter in the */
	int ncmp;           /* number of cmp gathers */
	float dt;           /* sampling rate */
	int start_cmp;      /* number of the first cmp gather */
	float freq[5];      /* the five spectral decomposing frequencies */
	float min_offset;   /* the min offset value; */
	float trace_space;  /* the space for two neighbouring traces */
	int start_point;    /* the sampling point starting for favo calculation*/
	float win1, win2;    /* reference time window for spectral balancing */
	float mtpseis = 1;  /*make sure there is no zero value in the data when balancing */
	int counter = 0;
	int i, j, k,l,t, ik, st,sk,ts;
	size_t tracebytes, databytes;
	int first = 0;     /*flag, is this the first ensemble being read?  */
	
	float **RR, **bb10;            //116=traces(29)*(nfreq-1)(4)
	float **RM;
	float **A;
	float **m, **md;
	
	float **AT=NULL,**B=NULL,**C=NULL;
	float **pref1=NULL, **sref1=NULL;
	float **RMT=NULL, **C1=NULL, **pddref=NULL, **sddref=NULL;
	
	
	/* Initialize */
	
	initargs(argc, argv);
	requestdoc(1);

	/****************************************************************/
	/*		Checking and Reading the data   		*/
	/****************************************************************/
	
	/*getting optional parameter specifying the five frequencies of data volume 
	be processed. the default values are set as the values for the test data.*/
	
	if(!getparint("ntraces", &ntraces)) ntraces=29;
	if(!getparint("ns", &ns)) ns=750;
	if(!getparint("ncmp", &ncmp)) ncmp=141;
	if(!getparfloat("dt", &dt)) dt=0.004;
	if(!getparint("startcmp", &start_cmp)) start_cmp=1700;
	if(!getparfloat("freq", freq)) {freq[0]=30;freq[1]=10;freq[2]=20;freq[3]=40;freq[4]=50;}
	if(!getparfloat("minoffset", &min_offset)) min_offset=50.0;
	if(!getparfloat("trspace", &trace_space)) trace_space=50.0;
	if(!getparint("startpoint", &start_point)) start_point=100;
	if(!getparfloat("win1", &win1)) win1=0.85;
	if(!getparfloat("win2", &win2)) win2=0.95;
	
	int win_start = (int)(win1/dt);
	int win_end = (int)(win2/dt);
	
	/* getting the names of the input files */
	if (!getparstring("inSD0",&inSD0))
		err("no file specified for inSD0 volume. Aborting...");
	if (!getparstring("inSD1",&inSD1))
		err("no file specified for inSD1 volume. Aborting...");
	if (!getparstring("inSD2",&inSD2))
		err("no file specified for inSD2 volume. Aborting...");
	if (!getparstring("inSD3",&inSD3))
		err("no file specified for inSD3 volume. Aborting...");
	if (!getparstring("inSD4",&inSD4))
		err("no file specified for inSD4 volume. Aborting...");
	if(!getparstring("inSD5",&inSD5))
		err("no file specified for inSD5 volume. Aborting...");
	if(!getparstring("inVP",&inVP))
		err("no file specified for inVP data. Aborting...");
	
	
	/* Allocating memory and initializing the data */
	Dp = ealloc2float(ntraces,ns);  //Dp is Dp[ns][ntraces]
	B1 = ealloc2float(ntraces,ns);
	B2 = ealloc2float(ntraces,ns);
	B3 = ealloc2float(ntraces,ns);
	B4 = ealloc2float(ntraces,ns);
	B5 = ealloc2float(ntraces,ns);
	D1b = ealloc2float(ntraces,ns);
	D2b = ealloc2float(ntraces,ns);
	D3b = ealloc2float(ntraces,ns);
	D4b = ealloc2float(ntraces,ns);
	D5b = ealloc2float(ntraces,ns);
	
	inSD0_gthr = ealloc2float(ns,ntraces);
	inSD1_gthr = ealloc2float(ns,ntraces);
	inSD2_gthr = ealloc2float(ns,ntraces);
	inSD3_gthr = ealloc2float(ns,ntraces);
	inSD4_gthr = ealloc2float(ns,ntraces);
	inSD5_gthr = ealloc2float(ns,ntraces);
	
	vp = ealloc1float(ns);
	vs = ealloc1float(ns);
	twt = ealloc1float(ns);
	h = ealloc1float(ns);
	//plfref = ealloc1float(ns);
	//pdd2ref = ealloc1float(ns);
	//slfref = ealloc1float(ns);
	
	x = ealloc1float(ntraces);
	m1 = ealloc1float(ntraces);
	m2 = ealloc1float(ntraces);
	m3 = ealloc1float(ntraces);
	m4 = ealloc1float(ntraces);
	m5 = ealloc1float(ntraces);
	a2IF = ealloc1float(ntraces);
	a3IF = ealloc1float(ntraces);
	a4IF = ealloc1float(ntraces);
	a5IF = ealloc1float(ntraces);
	
	dd = ealloc1float(ntraces);
	bb1 = ealloc1float(ntraces),
	bb2 = ealloc1float(ntraces),
	bb3 = ealloc1float(ntraces),
	bb4 = ealloc1float(ntraces),
	bb5 = ealloc1float(ntraces);
	
	theta = ealloc2float(ntraces,ns);
	pvel = ealloc2float(ntraces,ns);
	svel = ealloc2float(ntraces,ns);
	
	AT = ealloc2float(ntraces,2);
	B = ealloc2float(2,2);
	C = ealloc2float(ntraces,2);
	pref1 = ealloc2float(ncmp,ns);
	sref1 = ealloc2float(ncmp,ns);
	
	sk = ntraces*(5-1);
	RMT = ealloc2float(sk, 2);
	C1 = ealloc2float(sk,2);
	pddref = ealloc2float(ncmp,ns);
	sddref = ealloc2float(ncmp,ns);
		
	RR = ealloc2float(1,sk);         //RR[sk][1]
	bb10 = ealloc2float(1,ntraces); //bb10[ntraces][1]
	RM = ealloc2float(2,sk);
	A = ealloc2float(2,ntraces);
	m = ealloc2float(1,2);
	md = ealloc2float(1,2);
	
	warn("Please make sure these information are correct.");	
	warn("ns= %d, number of cdp=%d, cdp traces=%d",ns,ncmp,ntraces);
	
	memset((void *)pref1[0],0.0,ns*ncmp*sizeof(float));
	memset((void *)sref1[0],0.0,ns*ncmp*sizeof(float));
	memset((void *)pddref[0],0.0,ns*ncmp*sizeof(float));
	memset((void *)sddref[0],0.0,ns*ncmp*sizeof(float));
	memset((void *)theta[0],0.0,ns*ntraces*sizeof(float));
	memset((void *)pvel[0],0.0,ns*ntraces*sizeof(float));
	memset((void *)svel[0],0.0,ns*ntraces*sizeof(float));
	
		//Reading su data and vp from files
	SD0fp = open_vol(inSD0, &ns, &dt, &inSD0_tr);
	SD1fp = open_vol(inSD1, &ns, &dt, &inSD1_tr);
	SD2fp = open_vol(inSD2, &ns, &dt, &inSD2_tr);
	SD3fp = open_vol(inSD3, &ns, &dt, &inSD3_tr);
	SD4fp = open_vol(inSD4, &ns, &dt, &inSD4_tr);
	SD5fp = open_vol(inSD5, &ns, &dt, &inSD5_tr);
	VPfp = read_velocity(inVP, ns, vp);
	
	tracebytes = FSIZE * ns;
	databytes  = tracebytes * ntraces;
	
	for (i=0;i<ns;i++) vs[i] = 0.65 * vp[i] - 502;
	for (i=0;i<ns;i++) twt[i] = dt*i;
	h[0]=0;
	for (i=0;i<ns-1;i++) h[i+1] = h[i] + (twt[i+1]-twt[i])*vp[i+1]/2;
	for (j=0;j<ntraces;j++)x[j]=(min_offset+j*trace_space)/2;
	
	// given t --> vp & vs & theta
	for (i=start_point;i<ns;i++)
	{
		for (j=0;j<ntraces;j++)
		{
			pvel[i][j] = vp[i];
			svel[i][j] = vs[i];
			theta[i][j] = atan(x[j]/h[i]);
			//theta1[i][j] =theta[i][j]*180/3.14159;
		}
	}
	
	
	/* verifying the existence of input file */  
	if ((fp0 = fopen(inSD0,"r")) == NULL)err("cannot open file %s\n",inSD0);
	if ((fp1 = fopen(inSD1,"r")) == NULL)err("cannot open file %s\n",inSD1);
	if ((fp2 = fopen(inSD2,"r")) == NULL)err("cannot open file %s\n",inSD2);
	if ((fp3 = fopen(inSD3,"r")) == NULL)err("cannot open file %s\n",inSD3);
	if ((fp4 = fopen(inSD4,"r")) == NULL)err("cannot open file %s\n",inSD4);
	if ((fp5 = fopen(inSD5,"r")) == NULL)err("cannot open file %s\n",inSD5);

	for(ik=start_cmp;ik<start_cmp+ncmp;ik++)
	{
	    ts = getgather(fp0, ntraces,inSD0_gthr);
        ts = getgather(fp1, ntraces,inSD1_gthr);
	    ts = getgather(fp2, ntraces,inSD2_gthr);
	    ts = getgather(fp3, ntraces,inSD3_gthr);
	    ts = getgather(fp4, ntraces,inSD4_gthr);
	    ts = getgather(fp5, ntraces,inSD5_gthr);
      	for (int k1 = 0; k1 < ns; k1++)
		{
			for(int k2 = 0; k2 < ntraces; k2++)
			{
				Dp[k1][k2] = inSD0_gthr[k2][k1];
			    B1[k1][k2] = inSD1_gthr[k2][k1]+0.01;
				B2[k1][k2] = inSD2_gthr[k2][k1]+0.01;
				B3[k1][k2] = inSD3_gthr[k2][k1]+0.01;
				B4[k1][k2] = inSD4_gthr[k2][k1]+0.01;
				B5[k1][k2] = inSD5_gthr[k2][k1]+0.01;
			}
		}
	    
		//spectral balancing
       	for (i=0;i<ntraces;i++)
		{
			m1[i]=0;m2[i]=0;m3[i]=0;m4[i]=0;m5[i]=0;
            for (j=win_start;j<win_end;j++)
			{
				m1[i] = m1[i]+B1[j][i]*B1[j][i];    //max(B1(j,i));
                m2[i] = m2[i]+B2[j][i]*B2[j][i];    //max(B2(j,i));
                m3[i] = m3[i]+B3[j][i]*B3[j][i];    //max(B3(j,i));
                m4[i] = m4[i]+B4[j][i]*B4[j][i];    //max(B4(j,i));
                m5[i] = m5[i]+B5[j][i]*B5[j][i];    //max(B5(j,i));
			}
            m1[i]=sqrt(m1[i]/(win_end-win_start+1));
            m2[i]=sqrt(m2[i]/(win_end-win_start+1));
            m3[i]=sqrt(m3[i]/(win_end-win_start+1));
            m4[i]=sqrt(m4[i]/(win_end-win_start+1));
            m5[i]=sqrt(m5[i]/(win_end-win_start+1));
		}
		
	    for (i=0;i<ntraces;i++)
		{
			a2IF[i]=m1[i]/m2[i];
            a3IF[i]=m1[i]/m3[i];
            a4IF[i]=m1[i]/m4[i];
            a5IF[i]=m1[i]/m5[i];
		}

        for (i=0;i<ntraces;i++)
		{
			for (j=0;j<ns;j++)
			{
				D1b[j][i]=B1[j][i];
                D2b[j][i]=a2IF[i]*B2[j][i];
                D3b[j][i]=a3IF[i]*B3[j][i];
                D4b[j][i]=a4IF[i]*B4[j][i];
                D5b[j][i]=a5IF[i]*B5[j][i];
				
			}
		}

	//INVERSION
        for (t = start_point;t < ns;t++)    //calcute from the data not be muted
       	{
			i=0;
			for (i=0;i<ntraces;i++)
			{
				dd[i] = Dp[t][i];
                bb1[i] = D1b[t][i];
                bb2[i] = D2b[t][i];
                bb3[i] = D3b[t][i];
                bb4[i] = D4b[t][i];
                bb5[i] = D5b[t][i];
			}

	        i=0;
            for(i=0;i<ntraces;i++)
			{
                A[i][0]=(5/8);
                A[i][0]=A[i][0]-0.5*((pow(svel[t][i], 2))/(pow(pvel[t][i],2)))*(pow(sin(theta[t][i]),2));
                A[i][0]=A[i][0]+0.5*(pow(tan(theta[t][i]),2));
			}
			
            i=0;
            for(i=0;i<ntraces;i++)
            A[i][1]=-4*((pow(svel[t][i],2))/(pow(pvel[t][i],2)))*(pow(sin(theta[t][i]),2));

//%%%%%%%%%%% Full Elastic Inversion %%%%%%%%%%%
// least squares solution for 15Hz 
	    	matrix_tranpose(A, ntraces, 2, AT);               //A:ntraces*2  AT:2*ntraces
	     	matrix_multiplication(AT, A, 2, ntraces, 2, B);   //AT:2*ntraces   A:ntraces*2  B:2*2
		    st = rinv(B,2);
		    matrix_multiplication(B, AT, 2, 2, ntraces, C);   //B:2*2   AT:2*ntraces   C:2*ntraces
		    bb10[0] = bb1;
		   	matrix_multiplication(C, bb10, 2, ntraces, 1, m);  //C:2*ntraces   bb1:ntraces*1    m:2*1
            //m = inv(A'*A)*A'*bb1;
            pref1[t][ik-start_cmp] = m[0][0];
            sref1[t][ik-start_cmp] = m[1][0];
  


            //%%%%%%%%%%% Dispersion Inversion
            //% use F=30Hz as reference in the calculation
            for(i=0;i<ntraces;i++)
			{
				 j=ntraces+i;
                 k=ntraces*2+i;
                 l=ntraces*3+i;
                 RR[i][0]=bb2[i]-(A[i][0]*m[0][0])-(A[i][1]*m[1][0]);
                 RR[j][0]=bb3[i]-(A[i][0]*m[0][0])-(A[i][1]*m[1][0]);
                 RR[k][0]=bb4[i]-(A[i][0]*m[0][0])-(A[i][1]*m[1][0]);
                 RR[l][0]=bb5[i]-(A[i][0]*m[0][0])-(A[i][1]*m[1][0]);
			}

            for(i=0;i<ntraces;i++)
			{
				j=ntraces+i;
                k=ntraces*2+i;
                l=ntraces*3+i;
                RM[i][0]=(freq[1]-freq[0])*A[i][0];     //10-30
                RM[j][0]=(freq[2]-freq[0])*A[i][0];     //20-30
                RM[k][0]=(freq[3]-freq[0])*A[i][0];     //40-30
                RM[l][0]=(freq[4]-freq[0])*A[i][0];     //50-30
                RM[i][1]=(freq[1]-freq[0])*A[i][1];
                RM[j][1]=(freq[1]-freq[0])*A[i][1];
                RM[k][1]=(freq[1]-freq[0])*A[i][1];
                RM[l][1]=(freq[1]-freq[0])*A[i][1];
			}

            //% least squares solution
			matrix_tranpose(RM, sk, 2, RMT);
	     	matrix_multiplication(RMT, RM, 2, sk, 2, B);
	     	st = rinv(B,2);
		    matrix_multiplication(B, RMT, 2, 2, sk, C1);
			matrix_multiplication(C1, RR, 2, sk, 1, md);   //C1: 2*sk
            //md=inv(RM'*RM)*RM'*RR;          //RM:sk*2    RR:sk*1   RM':2*sk
			pddref[t][ik-start_cmp]=md[0][0];
            sddref[t][ik-start_cmp]=md[1][0];
	    // warn("md[0][0]= %f",md[0][0]);
       
	    }
	    
	// write output file, copy header from input trace to output trace 
        memcpy ((void *) &outtr, (const void *) &inSD0_tr, HDRBYTES);
		outtr.tracr = (int)ik;
		outtr.tracl = (int)ik;
		outtr.d1 = (float) dt;
		outtr.ns = (int) ns;
		for (j=0;j<ns;j++) outtr.data[j] = pddref[j][ik-start_cmp];
		puttr (&outtr);
	}
	
	fclose(fp0);fclose(fp1);fclose(fp2);fclose(fp3);fclose(fp4);fclose(fp5);
	return(CWP_Exit());
}

void matrix_tranpose(float **a, int krow, int kline, float **b)
////////////////////////////////////////////////////////////////////////////
//	tran_mat: transposed matrix
//	mat: original matrix
//	krow: row number
//	kline: column number
////////////////////////////////////////////////////////////////////////////
{
	int k1, k2;   

	for (k1 = 0; k1 < krow; k1++)
	{
		for(k2 = 0; k2 < kline; k2++)
		{
			b[k2][k1] = a[k1][k2];
		}
	}
}


void matrix_multiplication(float **a, float **b, int m, int n, int k, float **c)
//a: matrix with m*n ;
//b: matri with n*k ;
//c: c=a*b, return m*k;
//m: row number of a; n: column number of a; k: column number of b 
{
    int i,j,l,u;
	float *a1, *b1, *c1;
	a1=malloc(m*n*sizeof(float));
    b1=malloc(n*k*sizeof(float));
    c1=malloc(m*k*sizeof(float));
	for (i=0; i<=m-1; i++)
	{
		for (j=0; j<=n-1; j++)
		  a1[i*n+j]=a[i][j];
	}
	
	for (i=0; i<=n-1; i++)
	{
		for (j=0; j<=k-1; j++)
			b1[i*k+j]=b[i][j];
	}
	
    for (i=0; i<=m-1; i++)
    for (j=0; j<=k-1; j++)
    {
		u=i*k+j; c1[u]=0.0;
		for (l=0; l<=n-1; l++)c1[u] = c1[u]+a1[i*n+l]*b1[l*k+j];
		c[i][j] = c1[u];
    }
	free(a1); free(b1);free(c1);
    return;
}


int rinv(float **a,int n)
//a is the matrix to be inversed. return its inverse matrix in a.
//n is the column and row of a.
{ 
	int *is,*js,i,j,k,l,u,v;
    float d,p,*a1;
    is=malloc(n*sizeof(int));
    js=malloc(n*sizeof(int));
	a1=malloc(n*n*sizeof(float));
	for (i=0; i<=n-1; i++)
	{
		for (j=0; j<=n-1; j++)
			a1[i*n+j]=a[i][j];
	}
	
    for (k=0; k<=n-1; k++)
      { d=0.0;
        for (i=k; i<=n-1; i++)
        for (j=k; j<=n-1; j++)
          { l=i*n+j; p=fabs(a1[l]);
            if (p>d) { d=p; is[k]=i; js[k]=j;}
          }
        if (d+1.0==1.0)
          { free(is); free(js); printf("err**not inv\n");
            return(0);
          }
        if (is[k]!=k)
          for (j=0; j<=n-1; j++)
            { u=k*n+j; v=is[k]*n+j;
              p=a1[u]; a1[u]=a1[v]; a1[v]=p;
            }
        if (js[k]!=k)
          for (i=0; i<=n-1; i++)
            { u=i*n+k; v=i*n+js[k];
              p=a1[u]; a1[u]=a1[v]; a1[v]=p;
            }
        l=k*n+k;
        a1[l]=1.0/a1[l];
        for (j=0; j<=n-1; j++)
          if (j!=k)
            { u=k*n+j; a1[u]=a1[u]*a1[l];}
        for (i=0; i<=n-1; i++)
          if (i!=k)
            for (j=0; j<=n-1; j++)
              if (j!=k)
                { u=i*n+j;
                  a1[u]=a1[u]-a1[i*n+k]*a1[k*n+j];
                }
        for (i=0; i<=n-1; i++)
          if (i!=k)
            { u=i*n+k; a1[u]=-a1[u]*a1[l];}
      }
    for (k=n-1; k>=0; k--)
      { if (js[k]!=k)
          for (j=0; j<=n-1; j++)
            { u=k*n+j; v=js[k]*n+j;
              p=a1[u]; a1[u]=a1[v]; a1[v]=p;
            }
        if (is[k]!=k)
          for (i=0; i<=n-1; i++)
            { u=i*n+k; v=i*n+is[k];
              p=a1[u]; a1[u]=a1[v]; a1[v]=p;
            }
      }
	  
	for (i=0; i<=n-1; i++)
	{
		for (j=0; j<=n-1; j++)
			a[i][j]=a1[i*n+j];
	}
    free(is); free(js);free(a1);
    return(1);
}

FILE * open_vol(cwp_String vol_name, int *ns, float *dt, segy *tr) 
/****************************************************************
 
	open_vol	a function to read the volumes of 
			input data. Outputs the file pointer fp
*****************************************************************
INPUT

	vol_name	string containing the name of the volume
			to be opened

	ns		integer containg the number of samples
			in the input trace

	dt		float for the sampling rate of the 
			input data
	
	tr 		trace structure that will contain the 
			trace data

OUTPUT
	fp, ns, dt and tr

*****************************************************************/
{
	int nt;
	segy tr2;
 	FILE *fp;	
	/* verifying the existence of input file */  
	    if ((fp = fopen(vol_name,"r")) == NULL)
	      {
		err("cannot open volume %s\n",vol_name);
	      }
	/* getting first trace from input file */
	    if (!fgettr(fp,&tr2))
	      {
		err("cannot read first trace in %s volume\n",vol_name);
	      }
	/* getting number of samples and sampling rate in sec */
	    nt = (int)tr2.ns;
	   *dt = ((double)tr2.dt)/1000000.0;
	   *ns=nt; 
	    if (dt == 0) err("dt not set in header for %s volume", vol_name);
	   *tr=tr2;
	return fp;   

}

FILE *read_velocity(char *filename, int ns, float *vp)
/****************************************************************
	read_velocity 		read P-wave velocity from file. 
*****************************************************************
INPUT
	filename		
OUTPUT
	fp, vp 

****************************************************************/
{
	FILE *fp;
	float a[10000];
       
	
    if ((fp = fopen(filename,"r")) == NULL)
    {
	   err("cannot open velocity file s%\n",filename);
    }
   
    for(int i=0;i<ns;i++)
	{
	    fscanf(fp , "%f" ,&vp[i]); 
	}
    fclose(fp);
	return fp;
}

int getgather(FILE *fp, int ntraces,float **cdptraces)
{
	register int i,nt;
	segy tr;
	for (i=0;i<ntraces;i++)
	{
        /* getting first trace from input file */
	    if (!fgettr(fp,&tr))err("cannot read first trace in .su file\n");
		nt = (int)tr.ns;
	    memset((void *)cdptraces[i],0.0,nt*sizeof(float));
        memcpy((void *)cdptraces[i],(const void *)tr.data,nt*sizeof(float));
	}
	return(1);
  /* end of file, no more trace to read */ 
    if (!fgettr(fp, &tr)) return(0);
}